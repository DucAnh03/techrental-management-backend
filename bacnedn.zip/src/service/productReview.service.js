import ProductReview from '../models/ProductReview.js';

const createProductReview = async (data) => {
    try {
        const productReviews = await ProductReview.create(data);
        return productReviews;
    } catch (error) {
        throw error;
    }
};
const deleteProductReviewById = async (_id) => {
    try {
        const productReview = await ProductReview.findByIdAndDelete(_id);
        return productReview;
    } catch (error) {
        throw error;
    }
};
const getAllProductReview = async () => {
    try {
        const productReviews = await ProductReview.find();
        return productReviews;
    } catch (error) {
        throw error;
    }
};
const getProductReviewById = async (_id) => {
    try {
        const productReview = await ProductReview.findById(_id);
        return productReview;
    } catch (error) {
        throw error;
    }
};
const getAllProductReviewByIdProduct = async (_id) => {
    try {
        const productReviews = await ProductReview.find({
            idProduct: _id
        });
        return productReviews;
    }
    catch (error) {
        throw error;
    }
}
export default {
    createProductReview, deleteProductReviewById, getAllProductReview,
    getProductReviewById, getAllProductReviewByIdProduct
};
